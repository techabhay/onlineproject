package shoppingCart;

import static org.junit.Assert.*;
import org.junit.Test;

import shoppingCart.service.CartCalculator;
import shoppingCart.service.impl.CartCalculatorImpl;

/**
 * @author Abhay Mishra
 */

public class FinalPriceTest {
	
	@Test
	public void testFinalPrice() {
		CartCalculator cartCalculator = new CartCalculatorImpl();
		double finalPrice = cartCalculator.getFinalPrice(11000);
		long actualFinalPrice = (long)finalPrice;  //assertEquals not work for double, need to typecast to long.
		long expectedFinalPrice = (long)8800.0;
		assertEquals(expectedFinalPrice, actualFinalPrice);
	}
}
