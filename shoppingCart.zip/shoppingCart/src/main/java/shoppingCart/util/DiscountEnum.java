package shoppingCart.util;

/**
 * @author Abhay Mishra
 */

public enum DiscountEnum {
	
	LIMIT_FIVE_THOUSAND(0), LIMIT_TEN_THOUSAND(10.0), ABOVE_LIMIT(20.0);

	private double discount;
	
	DiscountEnum(double discount) {
		this.discount = discount;
	}
	
	public double getDiscount() {
		return discount;
	}
}
