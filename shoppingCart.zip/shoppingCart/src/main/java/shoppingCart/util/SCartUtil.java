package shoppingCart.util;

/**
 * @author Abhay Mishra
 */

public class SCartUtil {

	public static double getDiscountOffered(double amount) {
		double discount = 0.0;
		try {			
			if ((amount < 0) || ((0 <= amount) && (amount <= 5000))) {
				discount = DiscountEnum.LIMIT_FIVE_THOUSAND.getDiscount();
			} else if ((5000 < amount) && (amount <= 10000)) {
				discount = DiscountEnum.LIMIT_TEN_THOUSAND.getDiscount();
			} else {
				discount = DiscountEnum.ABOVE_LIMIT.getDiscount();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return discount;
	}

}
