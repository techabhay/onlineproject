package shoppingCart.model;

/**
 * @author Abhay Mishra
 */

public class Cart {
	
	public Cart(double purchaseAmount, double finalPrice) {
		super();
		this.purchaseAmount = purchaseAmount;
		this.finalPrice = finalPrice;
	}
	
	private double purchaseAmount;
	private double finalPrice;
	
	public double getPurchaseAmount() {
		return purchaseAmount;
	}
	public void setPurchaseAmount(double purchaseAmount) {
		this.purchaseAmount = purchaseAmount;
	}
	public double getFinalPrice() {
		return finalPrice;
	}
	public void setFinalPrice(double finalPrice) {
		this.finalPrice = finalPrice;
	}
	
	
}
