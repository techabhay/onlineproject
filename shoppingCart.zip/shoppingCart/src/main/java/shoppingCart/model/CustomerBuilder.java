package shoppingCart.model;

/**
 * @author Abhay Mishra
 */

public class CustomerBuilder {

	private int customerId;
	private String customerType;
	private String customerName;
	private Cart cart;
		
	
	public int getCustomerId() {
		return customerId;
	}
	public CustomerBuilder setCustomerId(int customerId) {
		this.customerId = customerId;
		return this;
	}
	public String getCustomerType() {
		return customerType;
	}
	public CustomerBuilder setCustomerType(String customerType) {
		this.customerType = customerType;
		return this;
	}
	public String getCustomerName() {
		return customerName;
	}
	public CustomerBuilder setCustomerName(String customerName) {
		this.customerName = customerName;
		return this;
	}
	public Cart getCart() {
		return cart;
	}
	public CustomerBuilder setCart(Cart cart) {
		this.cart = cart;
		return this;
	}
	
	public Customer getCustomer() {
		return new Customer(this.getCustomerId(), this.getCustomerType(), this.getCustomerName(), this.getCart());
	}
}
