package shoppingCart.model;

/**
 * @author Abhay Mishra
 */

public class Customer {
	
	private int customerId;
	private String customerType;
	private String customerName;
	private Cart cart;
	
	public Customer() {
		super();
	}
	
	public Customer(int customerId, String customerType,
			String customerName, Cart cart) {
		super();
		this.customerId = customerId;
		this.customerType = customerType;
		this.customerName = customerName;
		this.cart = cart;
	}

	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	
	public String toString() {
		return 	"Id : " + this.getCustomerId() + "\t \n Name : " + this.getCustomerName() + "\t \n PurchaseAmount : " + this.getCart().getPurchaseAmount() +
				"\t \n FinalPrice : " + this.cart.getFinalPrice();
	}
}
