package shoppingCart.service;

/**
 * @author Abhay Mishra
 */

public interface CartCalculator {

	public double getFinalPrice(double purchaseAmount);
}
