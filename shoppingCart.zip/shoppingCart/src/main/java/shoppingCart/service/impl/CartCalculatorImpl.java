package shoppingCart.service.impl;

import shoppingCart.service.CartCalculator;
import shoppingCart.util.SCartUtil;

/**
 * @author Abhay Mishra
 */

public class CartCalculatorImpl implements CartCalculator {

	public double getFinalPrice(double purchaseAmount) {
		
		double discountOffered = SCartUtil.getDiscountOffered(purchaseAmount);		
		double finalPrice = purchaseAmount - ((purchaseAmount * discountOffered)/100);
		
		return finalPrice;
	}

	public double getTotalPurchaseAmount(double amount) {
		// we can have different logics to get purchase amount, for ex.. receiving items purchase in method parameter
		// and then calculating purchase amount based on items price.
		// As of now keeping the logic simple as per requirement.
		
		return amount;
	}
}
