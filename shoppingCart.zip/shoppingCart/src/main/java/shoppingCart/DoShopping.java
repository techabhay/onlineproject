package shoppingCart;

import shoppingCart.model.Cart;
import shoppingCart.model.Customer;
import shoppingCart.model.CustomerBuilder;
import shoppingCart.service.CartCalculator;
import shoppingCart.service.impl.CartCalculatorImpl;

/**
 * @author Abhay Mishra
 */

public class DoShopping {
	
	public static void main(String args[]) {
		DoShopping doShopping = new DoShopping();
		CartCalculator cartCalculator = new CartCalculatorImpl();
		
		// Required only purchase Amount
		System.out.println("Payment Details :: \n " + doShopping.doPayment(cartCalculator, 9000));
		
		// Required Customer detail along with Purchase Amount
		//System.out.println("Payment Details :: \n " + doShopping.doPayment(cartCalculator, 102, "Mishra", 11000));
	}
	
	public Customer getCustomer(double purchaseAmount) {
		Cart cart = new Cart(purchaseAmount, 0.0);
		return new CustomerBuilder().setCustomerId(101).setCustomerName("Abhay").setCart(cart).getCustomer();
	}
	
	public Customer getCustomer(int customerId, String customerName, double purchaseAmount) {
		Cart cart = new Cart(purchaseAmount, 0.0);
		return new CustomerBuilder().setCustomerId(customerId).setCustomerName(customerName).setCart(cart).getCustomer();
	}	

	public Customer doPayment(CartCalculator cartCalculator, double purchaseAmount) {
		Customer customer = this.getCustomer(purchaseAmount);
		customer.getCart().setFinalPrice(cartCalculator.getFinalPrice(purchaseAmount));
		return customer;
	}
	
	public Customer doPayment(CartCalculator cartCalculator, int customerId, String customerName, double purchaseAmount) {
		Customer customer = this.getCustomer(customerId, customerName, purchaseAmount);
		customer.getCart().setFinalPrice(cartCalculator.getFinalPrice(purchaseAmount));
		return customer;
	}
}
